// Função que muda o conteúdo do parágrafo quando o botão é clicado
function changeContent() {
    const message = document.getElementById("message");
    message.innerText = "Você clicou no botão! Agora temos uma nova mensagem.";
}
